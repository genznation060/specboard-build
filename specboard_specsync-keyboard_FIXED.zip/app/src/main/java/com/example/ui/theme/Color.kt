package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TechBlue = Color(0xFF0284C7)
val TechCyan = Color(0xFF38BDF8)
val TechAmber = Color(0xFFF59E0B)
val TechEmerald = Color(0xFF10B981)

// Dark Theme Colors
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF0F172A)
