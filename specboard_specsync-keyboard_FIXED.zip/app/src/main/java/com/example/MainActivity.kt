package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Smartphone
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import com.example.ui.SpecViewModel
import com.example.ui.components.DuplicatePhoneDialog
import com.example.ui.components.ImportTsvDialog
import com.example.ui.screens.BackupSettingsScreen
import com.example.ui.screens.ClipboardScreen
import com.example.ui.screens.DatabaseScreen
import com.example.ui.screens.KeyboardSandboxScreen
import com.example.ui.screens.PhoneDetailScreen
import com.example.ui.theme.SpecBoardTheme

enum class MainTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    DATABASE("Phones", Icons.Filled.Smartphone, Icons.Outlined.Smartphone, "tab_phones"),
    CLIPBOARD("Clipboard", Icons.Filled.Assignment, Icons.Outlined.Assignment, "tab_clipboard"),
    KEYBOARD("Keyboard", Icons.Filled.Keyboard, Icons.Outlined.Keyboard, "tab_keyboard"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings")
}

class MainActivity : ComponentActivity() {

    private val viewModel: SpecViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SpecBoardTheme {
                SpecBoardApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SpecBoardApp(viewModel: SpecViewModel) {
    var currentTab by remember { mutableStateOf(MainTab.DATABASE) }
    var showImportDialog by remember { mutableStateOf(false) }
    var initialImportText by remember { mutableStateOf("") }

    val activePhoneId by viewModel.activePhoneId.collectAsState()
    val pendingDuplicates by viewModel.pendingDuplicates.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (activePhoneId == null) {
                NavigationBar {
                    MainTab.values().forEach { tab ->
                        val selected = currentTab == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentTab = tab },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title
                                )
                            },
                            label = { Text(tab.title) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val phoneId = activePhoneId
            if (phoneId != null) {
                PhoneDetailScreen(
                    phoneId = phoneId,
                    viewModel = viewModel,
                    onBack = { viewModel.setActivePhoneId(null) }
                )
            } else {
                when (currentTab) {
                    MainTab.DATABASE -> {
                        DatabaseScreen(
                            viewModel = viewModel,
                            onPhoneSelected = { id -> viewModel.setActivePhoneId(id) },
                            onOpenImportDialog = {
                                initialImportText = ""
                                showImportDialog = true
                            }
                        )
                    }
                    MainTab.CLIPBOARD -> {
                        ClipboardScreen(
                            viewModel = viewModel,
                            onOpenImportWithText = { text ->
                                initialImportText = text
                                showImportDialog = true
                            }
                        )
                    }
                    MainTab.KEYBOARD -> {
                        KeyboardSandboxScreen(viewModel = viewModel)
                    }
                    MainTab.SETTINGS -> {
                        BackupSettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    // Import TSV Dialog
    if (showImportDialog) {
        ImportTsvDialog(
            initialText = initialImportText,
            onDismiss = { showImportDialog = false },
            onImportConfirmed = { rawTsv ->
                showImportDialog = false
                viewModel.processTsvImport(rawTsv)
            }
        )
    }

    // Duplicate Resolution Dialog Queue
    if (pendingDuplicates.isNotEmpty()) {
        val topDuplicate = pendingDuplicates.first()
        DuplicatePhoneDialog(
            parsedPhone = topDuplicate.parsedPhone,
            existingPhone = topDuplicate.existingPhone,
            onAction = { action ->
                viewModel.resolveDuplicate(action)
            }
        )
    }
}
