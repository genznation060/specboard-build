package com.example

import com.example.model.SmartphoneSpecDef
import com.example.parser.TsvParser
import com.example.queue.PasteQueueManager
import com.example.queue.QueueSeparator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    @Before
    fun setup() {
        PasteQueueManager.clear()
        PasteQueueManager.setSeparator(QueueSeparator.NEWLINE)
    }

    @Test
    fun testTsvDetection() {
        val nonTsv = "Samsung Galaxy S26 Ultra is a phone with 120Hz display"
        assertFalse(TsvParser.isLikelyTsv(nonTsv))

        val validTsv = "Samsung\tGalaxy S26 Ultra\tSamsung Galaxy S26 Ultra\t120Hz"
        assertTrue(TsvParser.isLikelyTsv(validTsv))
    }

    @Test
    fun test39ColumnTsvParsing() {
        val sampleRow = "Samsung\tGalaxy S26 Ultra\tSamsung Galaxy S26 Ultra\t2026, Feb\t$1299\t162.8 x 77.6 x 8.2 mm\t218 g\tTitanium\tIP68\tDual SIM\tAMOLED\t6.9 inch\t1440x3120\t120 hertz\t3000 nits\tGorilla Armor\tAndroid 16\tSnapdragon 8 Elite\tOcta-core\tAdreno 830\t16GB\t512GB\tNo\t200 MP\t50 MP\t50 MP\t8K@30fps\t12 MP\t5000 milliamp hours\t65 watt\t25 watt\t4.5 watt\t5G\tWi-Fi 7\tBluetooth 5.4\tYes\tUltrasonic\tStereo\tTitanium Black"

        val result = TsvParser.parseTsv(sampleRow)
        assertTrue(result.isTsv)
        assertEquals(1, result.parsedPhones.size)

        val phone = result.parsedPhones.first()
        assertEquals("Samsung", phone.brand)
        assertEquals("Galaxy S26 Ultra", phone.model)
        assertEquals("Samsung Galaxy S26 Ultra", phone.fullName)
        assertEquals(39, phone.fields.size)

        // Verify categories
        val refreshRateField = phone.fields.firstOrNull { it.fieldName.contains("Refresh Rate", ignoreCase = true) }
        assertNotNull(refreshRateField)
        assertEquals("120 hertz", refreshRateField?.fieldValue)
        assertEquals("DISPLAY", refreshRateField?.category)

        val batteryField = phone.fields.firstOrNull { it.fieldName.contains("Battery", ignoreCase = true) }
        assertNotNull(batteryField)
        assertEquals("5000 milliamp hours", batteryField?.fieldValue)
        assertEquals("BATTERY", batteryField?.category)
    }

    @Test
    fun testEmptyFieldPreservation() {
        val rowWithEmptyFields = "Vivo\tX300\tVivo X300\t\t\t\t\t\t\t\tAMOLED\t\t\t120Hz"
        val result = TsvParser.parseTsv(rowWithEmptyFields)
        val phone = result.parsedPhones.first()

        assertEquals("Vivo", phone.brand)
        assertEquals("X300", phone.model)
        // Ensure empty fields were not dropped
        assertTrue(phone.fields.size >= 14)
        val emptyField = phone.fields[3]
        assertEquals("", emptyField.fieldValue)
    }

    @Test
    fun testPasteQueueOperations() {
        PasteQueueManager.addItem("Samsung Galaxy S26 Ultra", "Phone")
        PasteQueueManager.addItem("6.9 inch", "Screen")
        PasteQueueManager.addItem("120 hertz", "Refresh Rate")

        assertEquals(3, PasteQueueManager.queue.value.size)

        val next = PasteQueueManager.popNext()
        assertEquals("Samsung Galaxy S26 Ultra", next?.value)
        assertEquals(2, PasteQueueManager.queue.value.size)

        PasteQueueManager.setSeparator(QueueSeparator.COMMA)
        val allDrained = PasteQueueManager.drainAll()
        assertEquals("6.9 inch, 120 hertz", allDrained)
        assertEquals(0, PasteQueueManager.queue.value.size)
    }
}
